export default function Navigation() {
    return (
        <nav id='top' className="flex justify-start bg-slate-200" aria-label="Breadcrumb">

            <span className='p-1 md:text-sm text-xs'>This website was created entirely by myself(Kyochul Jang), without the use of any pre-made themes or templates.</span>

        </nav>
    )

}